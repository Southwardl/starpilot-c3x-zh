#!/usr/bin/env bash
# StarPilot C3X 汉化 + 定制补丁 安装器
# 用法: sudo bash install.sh [--force] [--no-restart]
set -uo pipefail

OPENPILOT="${OPENPILOT_DIR:-/data/openpilot}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FORCE=0
NO_RESTART=0
for arg in "$@"; do
  case "$arg" in
    --force) FORCE=1 ;;
    --no-restart) NO_RESTART=1 ;;
    -h|--help)
      echo "用法: sudo bash install.sh [--force] [--no-restart]"
      echo "  --force       即使检测到已安装也重新覆盖"
      echo "  --no-restart  安装后不重启 comma.service"
      exit 0 ;;
  esac
done

RED=$'\033[31m'; GRN=$'\033[32m'; YEL=$'\033[33m'; CYN=$'\033[36m'; RST=$'\033[0m'
info() { echo "${CYN}[*]${RST} $*"; }
ok()   { echo "${GRN}[+]${RST} $*"; }
warn() { echo "${YEL}[!]${RST} $*"; }
err()  { echo "${RED}[-]${RST} $*" >&2; }

die() { err "$*"; exit 1; }

# ---------- 0. 环境检查 ----------
[ -d "$OPENPILOT" ] || die "找不到 $OPENPILOT，这不是 comma 设备？"
[ -f "$OPENPILOT/manifest.json" ] || [ -d "$OPENPILOT/selfdrive" ] || die "$OPENPILOT 不像 openpilot 目录"
[ -f "$HERE/manifest.json" ] || die "发布包不完整：缺 manifest.json"

if [ "$(id -u)" -ne 0 ]; then
  die "请用 sudo 运行：sudo bash install.sh"
fi

BASELINE_COMMIT="2589caad342a25f96412ef4027591387ffb06a4a"
info "目标目录: $OPENPILOT"

# 基线提示（非强制）
if [ -f "$OPENPILOT/build.json" ]; then
  CUR_COMMIT=$(grep -o '"git_commit"[^,]*' "$OPENPILOT/build.json" 2>/dev/null | cut -d'"' -f4 || true)
  if [ -n "${CUR_COMMIT:-}" ] && [ "$CUR_COMMIT" != "$BASELINE_COMMIT" ]; then
    warn "当前 commit ($CUR_COMMIT) 与发布包基线 ($BASELINE_COMMIT) 不同"
    warn "补丁可能无法应用。用 --force 可忽略冲突继续。"
    [ "$FORCE" -eq 1 ] || die "已中止。确认要试就加 --force"
  fi
fi

# ---------- 1. 备份 ----------
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$OPENPILOT/.zh_backup_$STAMP"
info "备份现有文件到 $BACKUP"
mkdir -p "$BACKUP"
python3 - "$HERE" "$OPENPILOT" "$BACKUP" <<'PYEOF'
import json, pathlib, shutil, sys
here, target, backup = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[3])
manifest = json.loads((here / "manifest.json").read_text(encoding="utf-8"))
n = 0
for entry in manifest["entries"]:
    src = target / entry["target"]
    if not src.exists():
        continue
    dst = backup / entry["target"]
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    n += 1
print(f"  已备份 {n} 个文件")
(backup / ".backup_paths").write_text(
    "\n".join(e["target"] for e in manifest["entries"]), encoding="utf-8")
PYEOF
ok "备份完成"

# ---------- 2. 应用补丁 ----------
info "应用代码补丁"
FAIL=0
for p in "$HERE"/patch/*.patch; do
  [ -f "$p" ] || continue
  name="$(basename "$p")"
  if patch -p1 -d "$OPENPILOT" --dry-run --silent < "$p" >/dev/null 2>&1; then
    patch -p1 -d "$OPENPILOT" --silent < "$p" && ok "  $name"
  elif patch -p1 -d "$OPENPILOT" -R --dry-run --silent < "$p" >/dev/null 2>&1; then
    ok "  $name (已应用，跳过)"
  else
    if [ "$FORCE" -eq 1 ]; then
      warn "  $name 冲突，强制应用（可能产生 .rej）"
      patch -p1 -d "$OPENPILOT" --forward < "$p" || true
    else
      err "  $name 应用失败（用 --force 可强制尝试）"
      FAIL=$((FAIL+1))
    fi
  fi
done
[ "$FAIL" -eq 0 ] || warn "$FAIL 个补丁未能干净应用，检查 $OPENPILOT 下的 .rej 文件"

# ---------- 3. 投放文件 ----------
info "投放新文件与生成物"
python3 - "$HERE" "$OPENPILOT" <<'PYEOF'
import json, pathlib, shutil, sys
here, target = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
manifest = json.loads((here / "manifest.json").read_text(encoding="utf-8"))
n = 0
for entry in manifest["entries"]:
    if entry["kind"] != "drop":
        continue
    src = here / entry["file"]
    if not src.exists():
        print(f"  缺文件: {entry['file']}")
        continue
    dst = target / entry["target"]
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    n += 1
print(f"  已投放 {n} 个文件")
PYEOF
ok "文件投放完成"

# ---------- 4. 权限修正 ----------
info "修正文件所有者"
chown -R comma:comma "$OPENPILOT/selfdrive/ui" "$OPENPILOT/selfdrive/assets" 2>/dev/null || true
chown comma:comma "$OPENPILOT/build.json" 2>/dev/null || true
chown -R comma:comma "$OPENPILOT/system/ui" 2>/dev/null || true
chown -R comma:comma "$OPENPILOT/opendbc_repo/opendbc/car/gm" 2>/dev/null || true
ok "权限已修正"

# ---------- 5. 清缓存 ----------
info "清理 Python 缓存"
find "$OPENPILOT" -name "__pycache__" -type d -prune -exec rm -rf {} + 2>/dev/null || true
ok "缓存已清理"

# ---------- 6. 设置语言 ----------
info "设置语言为简体中文"
python3 - <<'PYEOF'
import os, pathlib
params = pathlib.Path("/data/params/d")
params.mkdir(parents=True, exist_ok=True)
(params / "LanguageSetting").write_bytes(b"main_zh-CHS")
try:
    os.chown(params / "LanguageSetting", 1000, 1000)
except Exception:
    pass
os.chmod(params / "LanguageSetting", 0o600)
print("  LanguageSetting = main_zh-CHS")
PYEOF
ok "语言已设置"

# ---------- 7. 重启 ----------
if [ "$NO_RESTART" -eq 0 ]; then
  info "重启 comma.service"
  systemctl restart comma.service || warn "重启失败，请手动：sudo systemctl restart comma.service"
  sleep 5
  ok "已重启"
else
  warn "按 --no-restart 跳过重启。手动执行：sudo systemctl restart comma.service"
fi

echo
ok "安装完成！"
echo "  备份目录: $BACKUP"
echo "  回滚:     sudo bash $HERE/uninstall.sh $BACKUP"
echo "  查看日志: journalctl -u comma -f"
