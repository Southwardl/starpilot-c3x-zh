#!/usr/bin/env python3
"""用 Pillow 生成 BMFont (.fnt + .png) 图集。

字符集来源：
  1) ASCII 可打印区 + 特殊符号
  2) app_zh-CHS.po 的全部字符
  3) 代码树里所有字符串字面量中的 CJK 字符（含直接写在 Python 里的中文）
"""
import re
import sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

FONT_DIR = Path("/data/openpilot/selfdrive/assets/fonts")
SRC_FONT = Path("/usr/share/fonts/NotoSansSC-Regular.otf")
OUT_STEM = "NotoSansSC-Regular"
PO_PATH = Path("/data/openpilot/selfdrive/ui/translations/app_zh-CHS.po")
SCAN_ROOTS = [
    Path("/data/openpilot/selfdrive/ui"),
    Path("/data/openpilot/starpilot"),
    Path("/data/openpilot/system/ui"),
]

FONT_SIZE = 48
PADDING = 6
COLS = 40

EXTRA_CHARS = "–‑✓×°§•X⚙✕◀▶✔⌫⇧␣○●↳çêüñ–‑✓×°§•€£¥²⚠ⓘ"

# Python 源码里的字符串字面量（单/双引号，含 f-string）
STR_LITERAL = re.compile(r"""[rbfuRBFU]?(['"])((?:\\.|(?!\1).){0,400}?)\1""")


def _is_cjk(ch: str) -> bool:
    cp = ord(ch)
    return (0x4E00 <= cp <= 0x9FFF) or (0x3000 <= cp <= 0x303F) or (0xFF00 <= cp <= 0xFFEF)


def collect_chars() -> list[str]:
    chars = set(map(chr, range(32, 127)))
    chars |= set(EXTRA_CHARS)

    # 1) 翻译文件
    try:
        chars |= set(PO_PATH.read_text(encoding="utf-8"))
    except FileNotFoundError:
        pass

    # 2) 代码里的字符串字面量（只收 CJK，避免注释/docstring 撑爆图集）
    scanned = 0
    for root in SCAN_ROOTS:
        if not root.exists():
            continue
        for py in root.rglob("*.py"):
            if "__pycache__" in str(py):
                continue
            try:
                text = py.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            scanned += 1
            for match in STR_LITERAL.finditer(text):
                for ch in match.group(2):
                    if _is_cjk(ch):
                        chars.add(ch)

    print(f"  扫描 py 文件: {scanned}")
    return sorted({c for c in chars if ord(c) >= 32 and c not in "\r\n"})


def main() -> int:
    font = ImageFont.truetype(str(SRC_FONT), FONT_SIZE)
    ascent, descent = font.getmetrics()
    line_height = ascent + descent

    chars = collect_chars()
    n = len(chars)
    rows = (n + COLS - 1) // COLS
    cell = FONT_SIZE + PADDING
    atlas_w = COLS * cell
    atlas_h = rows * cell

    cover = Image.new("L", (atlas_w, atlas_h), 0)
    draw = ImageDraw.Draw(cover)

    entries = []
    for idx, ch in enumerate(chars):
        col, row = idx % COLS, idx // COLS
        x0, y0, x1, y1 = font.getbbox(ch)
        w, h = x1 - x0, y1 - y0
        advance = int(round(font.getlength(ch)))
        if w > 0 and h > 0:
            draw.text((col * cell - x0, row * cell - y0), ch, font=font, fill=255)
        entries.append({
            "id": ord(ch), "x": col * cell, "y": row * cell,
            "width": max(w, 0), "height": max(h, 0),
            "xoffset": x0, "yoffset": y0, "xadvance": advance,
        })

    la = Image.merge("LA", (Image.new("L", (atlas_w, atlas_h), 255), cover))
    png_path = FONT_DIR / f"{OUT_STEM}.png"
    la.save(png_path)

    lines = [
        f'info face="{OUT_STEM}" size=-{FONT_SIZE} bold=0 italic=0 charset="" unicode=1 stretchH=100 smooth=0 aa=1 padding=0,0,0,0 spacing=0,0 outline=0',
        f"common lineHeight={line_height} base={ascent} scaleW={atlas_w} scaleH={atlas_h} pages=1 packed=0 alphaChnl=0 redChnl=4 greenChnl=4 blueChnl=4",
        f'page id=0 file="{OUT_STEM}.png"',
        f"chars count={len(entries)}",
    ]
    for e in entries:
        lines.append(
            "char id={id:<4} x={x:<5} y={y:<5} width={width:<5} height={height:<5} "
            "xoffset={xoffset:<5} yoffset={yoffset:<5} xadvance={xadvance:<5} page=0  chnl=15".format(**e)
        )
    fnt_path = FONT_DIR / f"{OUT_STEM}.fnt"
    fnt_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"  字符数: {len(entries)}")
    print(f"  图集: {atlas_w}x{atlas_h}")
    # 校验关键中文
    ids = {e["id"] for e in entries}
    for ch in "毫米波雷达可用不可用横向纵向扩展硬件车辆识结果":
        if ord(ch) not in ids:
            print(f"  ⚠ 缺字: {ch}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
